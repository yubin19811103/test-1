#ifndef _OS_BITS_H
#define _OS_BITS_H

#define OS_BITS  64
#define OFF_BITS 64

#endif
